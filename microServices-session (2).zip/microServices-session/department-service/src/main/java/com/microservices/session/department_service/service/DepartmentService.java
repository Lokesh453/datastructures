package com.microservices.session.department_service.service;

import com.microservices.session.department_service.model.Department;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface DepartmentService {
    public List<Department> findAll();

    public Department findByDepartmentId(Long id) throws Exception;

    public List<Department> addDepartment(Department department);
}
