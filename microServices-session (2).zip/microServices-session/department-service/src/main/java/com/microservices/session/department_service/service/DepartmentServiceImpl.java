package com.microservices.session.department_service.service;

import com.microservices.session.department_service.model.Department;
import com.microservices.session.department_service.repository.DepartmentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentServiceImpl implements  DepartmentService{
    @Autowired
    private DepartmentRepository departmentRepository;

    Logger logger
            = LoggerFactory.getLogger(DepartmentRepository.class);


    public List<Department> findAll() {
        logger.info("Entry ==> findAll ");
        return departmentRepository.findALlDepartments();

    }

    public Department findByDepartmentId(Long id) throws Exception {
        logger.info("Entry ==> findByDepartmentId ");
       return departmentRepository.findById(id);
    }

    public List<Department> addDepartment(Department department) {
        logger.info("Entry ==> addDepartment ");
        return departmentRepository.addDepartment(department);
    }
}
