package com.microservices.session.department_service.repository;

import com.microservices.session.department_service.model.Department;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class DepartmentRepository {
    private List<Department> departments = new ArrayList<>();


    public List<Department> addDepartment(Department department) {
        departments.add(department);
        return departments;
    }

    public List<Department> findALlDepartments() {
        return departments;
    }

    public Department findById(Long id) throws Exception {
        Optional<Department> departmentFound =  departments.stream().filter(department -> department.getId().equals(id)).findFirst();
        if(departmentFound.isEmpty()) {
            throw new Exception("Department not found by ID ");
        }
        return departmentFound.get();
    }
}
