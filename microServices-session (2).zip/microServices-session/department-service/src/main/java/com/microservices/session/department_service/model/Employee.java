package com.microservices.session.department_service.model;

public class Employee {

    private Long id;
    private Long departmentId;
    private String name ;

    public Employee() {
    }

    public Employee(Long id, Long departmentId, String name, int age) {
        this.id = id;
        this.departmentId = departmentId;
        this.name = name;
        this.age = age;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    private int age ;

}
