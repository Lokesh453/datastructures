package com.microservices.session.department_service.controller;

import com.microservices.session.department_service.model.Department;
import com.microservices.session.department_service.service.DepartmentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/departments")
public class DepartmentController {

    Logger logger
            = LoggerFactory.getLogger(DepartmentController.class);

    @Autowired
    private DepartmentService service;

    @GetMapping("/welcome")
    public String welcome(@RequestParam(required = false) String name) {
        return String.format("Hi %s Welcome to Springboot Session", name);
    }

    @GetMapping("/list")
    public List<Department> listDepartments() {
        logger.info("Finding all departments ");
        return service.findAll();

    }

    @PostMapping("/department")
    public ResponseEntity<?> addDepartment(@RequestBody Department department) {
        logger.info("Adding Department ");
        return ResponseEntity.ok(service.addDepartment(department));


    }

    @GetMapping("/{id}")
    public Department findDepartmentbyId(@PathVariable Long id) throws Exception {
        logger.info("Finding Department by Id ");
        return service.findByDepartmentId(id);

    }

}
